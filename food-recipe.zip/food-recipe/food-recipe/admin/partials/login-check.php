<?php
//Authorization access control
//check whetehr the user us logged in or not
if(!isset($_SESSION['user'])) // if user session is not det 
{
    //user is not logged in 
    //rediret to loging page with message
    $_SESSION['no-login-message'] = "<div style='color:red'>Please login to access Admin Pannel.</div> ";
    //redirect to login page
    header('location'.SITEURL.'admin/login.php');
}
?>