<?php 
ob_start(); // Start output buffering
include('partials/menu.php'); 
?>

<div class="main-content">
    <div class="wrapper">
        <h1>Add Recipe</h1>
        <br><br>
        <?php
        if(isset($_SESSION['upload'])) {
            echo $_SESSION['upload'];
            unset($_SESSION['upload']);
        }
        ?>

        <form action="" method="POST" enctype="multipart/form-data">
            <table class="tbl-30">
                <tr>
                    <td>Title:</td>
                    <td>
                        <input type="text" name="title" placeholder="Enter title">
                    </td>
                </tr>
                <tr>
                    <td>Description:</td>
                    <td>
                        <textarea name="description" cols="40" rows="10" placeholder="Enter description"></textarea>
                    </td>
                </tr>
                <tr>
                    <td>Ingredients:</td>
                    <td id="ingredient-section">
                        <div>
                            <input type="text" name="ingredients[]" placeholder="Enter ingredient">
                            <button type="button" onclick="addIngredient()">Add More</button>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>Select Image:</td>
                    <td>
                        <input type="file" name="image">
                    </td>
                </tr>
                <tr>
                    <td>Category:</td>
                    <td>
                        <select name="category" id="category">
                            <?php
                            $sql = "SELECT * FROM tbl_category WHERE active='Yes'";
                            $res = mysqli_query($conn, $sql);
                            $count = mysqli_num_rows($res);

                            if($count > 0) {
                                while($row = mysqli_fetch_assoc($res)) {
                                    $id = $row['id'];
                                    $title = $row['title'];
                                    ?>
                                    <option value="<?php echo $id; ?>"><?php echo $title; ?></option>
                                    <?php
                                }
                            } else {
                                ?>
                                <option value="0">No Category Found</option>
                                <?php
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Sub-Category:</td>
                    <td>
                        <select name="sub_category" id="sub_category">
                            <option value="0">Select Sub-Category</option>
                            <?php
                            $sql_sub = "SELECT * FROM tbl_sub_category";
                            $res_sub = mysqli_query($conn, $sql_sub);
                            $count_sub = mysqli_num_rows($res_sub);

                            if($count_sub > 0) {
                                while($row_sub = mysqli_fetch_assoc($res_sub)) {
                                    $sub_id = $row_sub['id'];
                                    $sub_title = $row_sub['title'];
                                    ?>
                                    <option value="<?php echo $sub_id; ?>"><?php echo $sub_title; ?></option>
                                    <?php
                                }
                            } else {
                                ?>
                                <option value="0">No Sub-Category Found</option>
                                <?php
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Featured:</td>
                    <td>
                        <input type="radio" name="featured" value="Yes">Yes
                        <input type="radio" name="featured" value="No">No
                    </td>
                </tr>
                <tr>
                    <td>Active:</td>
                    <td>
                        <input type="radio" name="active" value="Yes">Yes
                        <input type="radio" name="active" value="No">No
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <input type="submit" name="submit" value="Add Recipe" class="btn-add">
                    </td>
                </tr>
            </table>
        </form>

        <?php
        if(isset($_POST['submit'])) {
            $title = mysqli_real_escape_string($conn, $_POST['title']);
            $description = mysqli_real_escape_string($conn, $_POST['description']);
            $ingredients = mysqli_real_escape_string($conn, implode(", ", $_POST['ingredients']));
            $category = $_POST['category'];
            $sub_category = $_POST['sub_category'];
            $featured = isset($_POST['featured']) ? $_POST['featured'] : "No";
            $active = isset($_POST['active']) ? $_POST['active'] : "No";

            // Upload image if selected
            if(isset($_FILES['image']['name']) && $_FILES['image']['name'] != "") {
                $image_name = $_FILES['image']['name'];
                $ext = end(explode('.', $image_name));
                $image_name = "Food-Name-".rand(0000, 9999).".".$ext;
                $src = $_FILES['image']['tmp_name'];
                $dst = "../images/Food/".$image_name;

                if (!file_exists('../images/Food/')) {
                    mkdir('../images/Food/', 0777, true);
                }

                if(!move_uploaded_file($src, $dst)) {
                    $_SESSION['upload'] = "<div style='color:red'>Failed to Upload Image.</div>";
                    header('location:'.SITEURL.'admin/add-recipe.php');
                    ob_end_flush();
                    die();
                }
            } else {
                $image_name = ""; // Default value when no image is selected
            }

            // If no sub-category is selected, set it as NULL
            if($sub_category == "0") {
                $sub_category = "NULL";
            }

            // Insert into database
            $sql2 = "INSERT INTO tbl_food SET
                title='$title',
                description='$description',
                image_name='$image_name',
                category_id=$category,
                sub_category_id=$sub_category,
                featured='$featured',
                active='$active',
                ingredients='$ingredients'
            ";

            $res2 = mysqli_query($conn, $sql2);

            if($res2 == true) {
                $_SESSION['add'] = "<div style='color:green'>Recipe Added Successfully.</div>";
                header('location:'.SITEURL.'admin/manage-recipe.php');
                ob_end_flush();
            } else {
                $_SESSION['add'] = "<div style='color:red'>Failed to Add Recipe.</div>";
                header('location:'.SITEURL.'admin/manage-recipe.php');
                ob_end_flush();
            }
        }
        ?>
    </div>
</div>

<script>
function addIngredient() {
    const ingredientSection = document.getElementById('ingredient-section');
    const newIngredient = document.createElement('div');
    newIngredient.innerHTML = `
        <input type="text" name="ingredients[]" placeholder="Enter ingredient">
        <button type="button" onclick="removeIngredient(this)">Remove</button>
    `;
    ingredientSection.appendChild(newIngredient);
}

function removeIngredient(button) {
    button.parentElement.remove();
}
</script>

<?php ob_end_flush(); // End the output buffer ?>
