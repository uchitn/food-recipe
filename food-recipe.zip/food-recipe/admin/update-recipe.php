<?php 
include('partials/menu.php'); 
ob_start(); // Start output buffering
?>

<div class="main-content">
    <div class="wrapper">
        <h1>Update Recipe</h1>
        <br><br>

        <?php
        // Check whether id is set or not
        if(isset($_GET['id'])) {
            $id = $_GET['id'];

            // Fetch current details from the database
            $sql = "SELECT * FROM tbl_food WHERE id=$id";
            $res = mysqli_query($conn, $sql);

            if($res == true) {
                $count = mysqli_num_rows($res);
                if($count == 1) {
                    // Get details
                    $row = mysqli_fetch_assoc($res);
                    $title = isset($row['title']) ? $row['title'] : '';
                    $description = isset($row['description']) ? $row['description'] : '';
                    $ingredients = isset($row['ingredients']) ? $row['ingredients'] : '';
                    $current_image = isset($row['image_name']) ? $row['image_name'] : '';
                    $category_id = isset($row['category_id']) ? $row['category_id'] : 0;
                    $sub_category_id = isset($row['sub_category_id']) ? $row['sub_category_id'] : 0; // Fetch sub-category
                    $featured = isset($row['featured']) ? $row['featured'] : 'No';
                    $active = isset($row['active']) ? $row['active'] : 'No';
                } else {
                    // Redirect to manage food with a message
                    $_SESSION['no-food-found'] = "<div style='color:red;'>No Food Found.</div>";
                    header('location:'.SITEURL.'admin/manage-recipe.php');
                    ob_end_flush();
                    exit();
                }
            }
        } else {
            // Redirect to manage food
            header('location:'.SITEURL.'admin/manage-recipe.php');
            ob_end_flush();
            exit();
        }
        ?>

        <form action="" method="POST" enctype="multipart/form-data">
            <table class="tbl-30">
                <tr>
                    <td>Title:</td>
                    <td>
                        <input type="text" name="title" value="<?php echo $title; ?>">
                    </td>
                </tr>
                <tr>
                    <td>Ingredients:</td>
                    <td>
                        <textarea name="ingredients" cols="30" rows="5"><?php echo $ingredients; ?></textarea>
                    </td>
                </tr>
                <tr>
                    <td>Procedure:</td>
                    <td>
                        <textarea name="description" cols="30" rows="5"><?php echo $description; ?></textarea>
                    </td>
                </tr>
                <tr>
                    <td>Current Image:</td>
                    <td>
                        <?php
                        // Check if the current image exists and display it
                        if($current_image != "") {
                            $image_path = "../images/food/" . $current_image;
                            if(file_exists($image_path)) {
                                echo "<img src='$image_path' width='150px'>";
                            } else {
                                echo "<div style='color:red;'>Image Not Found: $image_path</div>";
                            }
                        } else {
                            echo "<div style='color:red;'>Image Not Added.</div>";
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td>New Image:</td>
                    <td>
                        <input type="file" name="image">
                    </td>
                </tr>
                <tr>
                    <td>Category:</td>
                    <td>
                        <select name="category" id="category">
                            <?php
                            $sql = "SELECT * FROM tbl_category WHERE active='Yes'";
                            $res = mysqli_query($conn, $sql);
                            $count = mysqli_num_rows($res);
                            if($count > 0) {
                                while($row = mysqli_fetch_assoc($res)) {
                                    $cat_id = $row['id'];
                                    $category_title = $row['title'];
                                    ?>
                                    <option value="<?php echo $cat_id; ?>" <?php if($cat_id == $category_id) {echo "selected";} ?>><?php echo $category_title; ?></option>
                                    <?php
                                }
                            } else {
                                ?>
                                <option value="0">No Category Found</option>
                                <?php
                            }
                            ?>
                        </select>
                    </td>
                </tr>

                <tr>
                    <td>Sub-Category:</td>
                    <td>
                        <select name="sub_category" id="sub-category">
                            <!-- Sub-categories will be populated here based on the selected category -->
                            <?php
                            $sql = "SELECT * FROM tbl_sub_category ";
                            $res = mysqli_query($conn, $sql);
                            $count = mysqli_num_rows($res);
                            if($count > 0) {
                                while($row = mysqli_fetch_assoc($res)) {
                                    $cat_id = $row['id'];
                                    $sub_category_title = $row['title'];
                                    ?>
                                    <option value="<?php echo $cat_id; ?>" <?php if($cat_id == $category_id) {echo "selected";} ?>><?php echo $sub_category_title; ?></option>
                                    <?php
                                }
                            } else {
                                ?>
                                <option value="0">No Sub-Category Found</option>
                                <?php
                            }
                            ?>
                        </select>
                    </td>
                </tr>

                <tr>
                    <td>Featured:</td>
                    <td>
                        <input type="radio" name="featured" value="Yes" <?php if($featured == "Yes"){echo "checked";} ?>> Yes
                        <input type="radio" name="featured" value="No" <?php if($featured == "No"){echo "checked";} ?>> No
                    </td>
                </tr>
                <tr>
                    <td>Active:</td>
                    <td>
                        <input type="radio" name="active" value="Yes" <?php if($active == "Yes"){echo "checked";} ?>> Yes
                        <input type="radio" name="active" value="No" <?php if($active == "No"){echo "checked";} ?>> No
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="hidden" name="current_image" value="<?php echo $current_image; ?>">
                        <input type="hidden" name="id" value="<?php echo $id; ?>">
                        <input type="submit" name="submit" value="Update Recipe" class="btn-add">
                    </td>
                </tr>
            </table>
        </form>

        <!-- JavaScript to dynamically load sub-categories based on category selection -->
        <script>
        document.getElementById('category').addEventListener('change', function() {
            var categoryId = this.value;
            var xhr = new XMLHttpRequest();
            xhr.open('POST', 'get-subcategories.php', true);
            xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            xhr.onload = function() {
                if (this.status == 200) {
                    document.getElementById('sub-category').innerHTML = this.responseText;
                }
            };
            xhr.send('category_id=' + categoryId);
        });

        // Trigger change event on page load to load current sub-category
        window.onload = function() {
            document.getElementById('category').dispatchEvent(new Event('change'));
        };
        </script>

        <?php
        if(isset($_POST['submit'])) {
            // Get all the details from the form
            $id = $_POST['id'];
            $title = mysqli_real_escape_string($conn, $_POST['title']);
            $description = mysqli_real_escape_string($conn, $_POST['description']);
            $ingredients = mysqli_real_escape_string($conn, $_POST['ingredients']);
            $current_image = $_POST['current_image'];
            $category = isset($_POST['category']) && $_POST['category'] > 0 ? mysqli_real_escape_string($conn, $_POST['category']) : 0;
            $sub_category = isset($_POST['sub_category']) && $_POST['sub_category'] > 0 ? mysqli_real_escape_string($conn, $_POST['sub_category']) : 0;
            $featured = isset($_POST['featured']) ? mysqli_real_escape_string($conn, $_POST['featured']) : "No";
            $active = isset($_POST['active']) ? mysqli_real_escape_string($conn, $_POST['active']) : "No";

            // Handle image upload
            if(isset($_FILES['image']['name']) && $_FILES['image']['name'] != "") {
                // Upload the new image
                $image_name = $_FILES['image']['name'];
                $source_path = $_FILES['image']['tmp_name'];
                $destination_path = "../images/food/".$image_name;

                // Upload the image
                $upload = move_uploaded_file($source_path, $destination_path);
                if(!$upload) {
                    $_SESSION['upload'] = "<div style='color:red;'>Failed to Upload Image.</div>";
                    header('location:'.SITEURL.'admin/manage-recipe.php');
                    ob_end_flush();
                    exit();
                }

                // Remove current image if available
                if($current_image != "") {
                    $remove_path = "../images/food/".$current_image;
                    if(file_exists($remove_path)) {
                        unlink($remove_path);
                    }
                }
            } else {
                $image_name = $current_image; // No change in image
            }

            // Update the database
            $sql2 = "UPDATE tbl_food SET
                title = '$title',
                description = '$description',
                ingredients = '$ingredients',
                image_name = '$image_name',
                category_id = '$category',
                sub_category_id = '$sub_category',
                featured = '$featured',
                active = '$active'
                WHERE id=$id";

            $res2 = mysqli_query($conn, $sql2);
            if($res2 == true) {
                $_SESSION['update'] = "<div style='color:green;'>Recipe Updated Successfully.</div>";
                header('location:'.SITEURL.'admin/manage-recipe.php');
                ob_end_flush();
                exit();
            } else {
                $_SESSION['update'] = "<div style='color:red;'>Failed to Update Recipe.</div>";
                header('location:'.SITEURL.'admin/manage-recipe.php');
                ob_end_flush();
                exit();
            }
        }
        ?>

    </div>
</div>


