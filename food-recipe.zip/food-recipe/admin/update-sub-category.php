<?php include('partials/menu.php')?>
<div class="main-content">
    <div class="wrapper">
        <h1>Update Sub-Category</h1>
        <br><br>

        <?php
        // Check whether the id is set or not
        if (isset($_GET['id'])) {
            $id = $_GET['id'];
            // Create SQL query to get other details
            $sql = "SELECT * FROM tbl_sub_category WHERE id=$id";

            // Execute the query
            $res = mysqli_query($conn, $sql);

            // Count the rows to check whether the id is valid or not
            $count = mysqli_num_rows($res);

            if ($count == 1) {
                // Then only we get all the data
                $row = mysqli_fetch_assoc($res);
                $title = $row['title'];
            } else {
                // Redirect to manage category page with message
                $_SESSION['no-category-found'] = "<div style='color:red'>Category not found</div>";
                header('location:' . SITEURL . 'admin/manage-sub-category.php');
            }
        } else {
            header('location:' . SITEURL . 'admin/manage-sub-category.php');
        }
        ?>

        <form action="" method="POST" enctype="multipart/form-data">
            <table class="tbl-30">
                <tr>
                    <td>Title:</td>
                    <td>
                        <input type="text" name="title" value="<?php echo $title; ?>">
                    </td>
                </tr>
                    
                <tr>
                    <td colspan="2">
                        <input type="hidden" name="id" value="<?php echo $id; ?>">
                        <input type="submit" name="submit" value="Update Category" class="btn-add">
                    </td>
                </tr>
            </table>
        </form>

        <?php
        if (isset($_POST['submit'])) {
            // Get all the values from our form 
            $id = $_POST['id'];
            $title = $_POST['title'];

            // Update the database
            $sql2 = "UPDATE tbl_sub_category SET 
                    title='$title' 
                    WHERE id=$id";

            // Execute the query
            $res = mysqli_query($conn, $sql2);

            // Redirect to manage category with message
            // Check whether query executed or not
            if ($res == TRUE) {
                // Category updated
                $_SESSION['update'] = "<div style='color:green'>Category Updated Successfully</div>";
                header("location:" . SITEURL . 'admin/manage-sub-category.php');
            } else {
                // Failed to update category
                $_SESSION['update'] = "<div style='color:red'>Failed to Update Category</div>";
                header("location:" . SITEURL . 'admin/manage-sub-category.php');
            }
        }
        ?>
    </div>
</div>
