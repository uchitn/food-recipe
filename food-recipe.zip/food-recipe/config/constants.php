<?php
    // Start session
    session_start();

// Create Constant to Store non reprating values
define('SITEURL', 'http://localhost/food-recipe/');
define('LOCALHOST','localhost');
define('DB_USERNAME','root');
define('DB_PASSWORD','');
define('DB_NAME','food-recipe');

$conn = mysqli_connect(LOCALHOST, DB_USERNAME, DB_PASSWORD, DB_NAME) or die('Connection failed: ' . mysqli_connect_error());
?>