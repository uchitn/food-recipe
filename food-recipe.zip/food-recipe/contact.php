<?php include('config/constants.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <!-- Important to make website responsive -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restaurant Website</title>

    <!-- Link our CSS file -->
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <!-- Navbar Section Starts Here -->
    <section class="navbar">
        <div class="container">
            <div class="logo">
                <a href="#" title="Logo">
                    <img src="images/test.png" alt="Restaurant Logo" class="img-responsive">
                </a>
            </div>

            <div class="menu text-right">
                <ul>
                    <li>
                        <a href="home.php">Home</a>
                    </li>
                    <li>
                        <a href="<?php echo SITEURL;?>category1.php">Categories</a>
                    </li>
                    <li>
                        <a href="<?php echo SITEURL;?>food1.php">Recipe</a>
                    </li>
                    <li>
                        <a href="Contact.php">Feedback</a>
                    </li>
                    <li>
                        <a href="login.php">Login</a>
                    </li>
                    <li>
                        <a href="admin/login.php">Admin-Login</a>
                    </li>
                </ul>
            </div>

            <div class="clearfix"></div>
        </div>
    </section>
    <!-- Navbar Section Ends Here -->
<div class="main-content">
    <div class="wrapper">
        <h1>Manage Feedback</h1>
        <br><br>

        <?php
        // Database connection
        $conn = mysqli_connect('localhost', 'root', '', 'food-recipe') or die(mysqli_error());

        // Check if a delete request was made
        if (isset($_POST['delete'])) {
            $feedback_id = $_POST['feedback_id'];
            $delete_sql = "DELETE FROM tbl_feedback WHERE id=$feedback_id";
            $delete_res = mysqli_query($conn, $delete_sql);

            if ($delete_res) {
                echo "<div style='color:green;'>Feedback deleted successfully.</div>";
            } else {
                echo "<div style='color:red;'>Failed to delete feedback.</div>";
            }
        }

        // Query to get all feedback from the database
        $sql = "SELECT * FROM tbl_feedback";
        $res = mysqli_query($conn, $sql);

        if ($res == true) {
            $count = mysqli_num_rows($res);

            if ($count > 0) {
                // Display feedback in boxes
                while ($row = mysqli_fetch_assoc($res)) {
                    $id = $row['id'];
                    $name = $row['name'];
                    $email = $row['email'];
                    $rating = $row['rating'];
                    $comments = $row['comments'];
                

                    ?>
                    <div class="feedback-box">
                        <h3><?php echo htmlspecialchars($name); ?></h3>
                        <p><strong>Email:</strong> <?php echo htmlspecialchars($email); ?></p>
                        <p><strong>Rating:</strong> <?php echo htmlspecialchars($rating); ?></p>
                        <p><strong>Comments:</strong> <?php echo nl2br(htmlspecialchars($comments)); ?></p>
                      
                        <!-- Delete button -->
                       
                    </div>
                    <?php
                }
            } else {
                echo "<div style='color:red;'>No feedback found.</div>";
            }
        } else {
            echo "<div style='color:red;'>Failed to retrieve feedback data.</div>";
        }

        // Close the database connection
        mysqli_close($conn);
        ?>
    </div>
</div>
