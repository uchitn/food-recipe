<?php
include('partials-front/menu.php');

if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id']; // Safely access user_id
} else {
    // Handle the case where the user is not logged in
    echo "User is not logged in.";
    // Optionally redirect to login page
    header('Location: login.php');
    exit();
}

// Check whether food id is set or not
if(isset($_GET['food_id'])){
    $food_id = $_GET['food_id'];

    // Fetch food details
    $sql = "SELECT * FROM tbl_food WHERE id = '$food_id'";
    $res = mysqli_query($conn, $sql);

    $count = mysqli_num_rows($res);

    if($count == 1){
        $row = mysqli_fetch_assoc($res);
        $title = $row['title'];
        $ingredients = $row['ingredients'];
        $description = $row['description'];
        $image_name = $row['image_name'];
    }
    else{
        header('location:'.SITEURL.'home.php');
    }

    // Check if the user has already viewed this food
    $sql_check_view = "SELECT * FROM tbl_user_food_views WHERE user_id = '$user_id' AND food_id = '$food_id'";
    $res_check_view = mysqli_query($conn, $sql_check_view);

    if(mysqli_num_rows($res_check_view) > 0){
        // User has already viewed, update the view count
        $sql_update_views = "UPDATE tbl_user_food_views SET view_count = view_count + 1, last_viewed = NOW() WHERE user_id = '$user_id' AND food_id = '$food_id'";
        mysqli_query($conn, $sql_update_views);
    }
    else{
        // First time viewing, insert into tbl_user_food_view
        $sql_insert_view = "INSERT INTO tbl_user_food_views (user_id, food_id, view_count) VALUES ('$user_id', '$food_id', 1)";
        mysqli_query($conn, $sql_insert_view);
    }

}
else{
    header('location:'.SITEURL.'home.php');
}

?>

<!-- fOOD sEARCH Section Starts Here -->
<section class="food-search">
    <div class="container">
        
        <h2 class="text-center text-white"><?php echo $title; ?></h2>

        <form action="#" class="order">
            <fieldset>
                <div>
                    <?php
                    if($image_name == ""){
                        echo "<div style='color:red'>Image not available.</div>";
                    }
                    else{
                        ?>
                        <img src="<?php echo SITEURL; ?>images/food/<?php echo $image_name; ?>" alt="Food Image">
                        <?php
                    }
                    ?>
                </div>
                <br><br><br>

                <div>
                    <h1>Ingredients:</h1>
                    <ul class="food-price">
                        <?php
                        $ingredients_list = explode(",", $ingredients);
                        foreach($ingredients_list as $ingredient){
                            echo "<li>" . trim($ingredient) . "</li>";
                        }
                        ?>
                    </ul>
                </div>

            </fieldset>
            
            <fieldset>
                <legend>Step for making recipe</legend>
                <h1>Procedure:</h1>
                <ol class="food-price">
                    <?php
                    $steps = explode("\n", $description);
                    foreach($steps as $step){
                        echo "<li>" . trim($step) . "</li>";
                    }
                    ?>
                </ol>
            </fieldset>

        </form>

    </div>
</section>
<!-- fOOD sEARCH Section Ends Here -->

<!-- Recommended for You Section -->
<section class="food-recommend">
    <div class="container">
        <h2 class="text-center text-white">Recommended for You</h2>

        <!-- Swiper -->
        <div class="swiper-container">
            <div class="swiper-wrapper">
                <?php
                // Fetch the top 5 most viewed recipes by the user that have at least 3 views
                $sql_recommend = "SELECT f.* FROM tbl_food f
                                  JOIN tbl_user_food_views v ON f.id = v.food_id
                                  WHERE v.user_id = '$user_id' AND v.view_count >= 3
                                  ORDER BY v.view_count DESC LIMIT 5";
                $res_recommend = mysqli_query($conn, $sql_recommend);

                if(mysqli_num_rows($res_recommend) > 0){
                    while($row_recommend = mysqli_fetch_assoc($res_recommend)){
                        $rec_id = $row_recommend['id'];
                        $rec_title = $row_recommend['title'];
                        $rec_image = $row_recommend['image_name'];
                        ?>
                        <div class="swiper-slide recommend-item">
                            <?php
                            if                            ($rec_image == ""){
                                echo "<div style='color:red'>Image not available.</div>";
                            } else {
                                ?>
                                <img src="<?php echo SITEURL; ?>images/food/<?php echo $rec_image; ?>" alt="Recommended Food">
                                <?php
                            }
                            ?>
                            <h3><?php echo $rec_title; ?></h3>
                            <a href="<?php echo SITEURL; ?>view.php?food_id=<?php echo $rec_id; ?>" class="btn">View Recipe</a>
                        </div>
                        <?php
                    }
                } else {
                    echo "<p>No recommendations available at the moment.</p>";
                }
                ?>
            </div>
            <!-- Add Pagination -->
            <div class="swiper-pagination"></div>
            <!-- Add Navigation -->
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
    </div>
</section>

<!-- Swiper JS -->
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>

<!-- Swiper Initialization -->
<script>
    var swiper = new Swiper('.swiper-container', {
        slidesPerView: 3,
        spaceBetween: 20,
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        breakpoints: {
            640: {
                slidesPerView: 1,
                spaceBetween: 10,
            },
            768: {
                slidesPerView: 2,
                spaceBetween: 15,
            },
            1024: {
                slidesPerView: 3,
                spaceBetween: 20,
            },
        },
    });
</script>

<!-- Custom CSS -->
<style>
/* Your existing CSS here */
.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 15px;
}

.food-recommend {
    background-color: #f8f8f8;
    padding: 50px 0;
}

.food-recommend h2 {
    color: black;
    margin-bottom: 30px;
}

/* Swiper Container */
.swiper-container {
    width: 100%;
    overflow: hidden;
}

.swiper-wrapper {
    display: flex;
}

/* Recommend Item Styles */
.recommend-item {
    flex: 0 0 30%;
    background-color: white;
    border: 1px solid #ddd;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    text-align: center;
    margin: 20px 0;
    padding: 20px;
    transition: 0.3s;
    box-sizing: border-box;
}

.recommend-item img {
    width: 100%;
    height: 200px;
    object-fit: cover;
    border-radius: 10px;
}

.recommend-item h3 {
    margin: 15px 0;
}

.recommend-item .btn {
    padding: 10px 20px;
    background-color: #f39c12;
    color: white;
    text-decoration: none;
    transition: background-color 0.3s ease;
}

.recommend-item .btn:hover {
    background-color: #e67e22;
}

/* Swiper Navigation Buttons */
.swiper-button-next, .swiper-button-prev {
    color: #f39c12;
    font-size: 20px;
    transition: color 0.3s ease;
}

.swiper-button-next:hover, .swiper-button-prev:hover {
    color: #e67e22;
}
</style>
    
</body>

</html>
