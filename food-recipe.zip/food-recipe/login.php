<?php
include('config/constants.php');
?>
<html>
<head>
    <title>Login Food Recipe System</title>
    <link rel="stylesheet" href="css/admin.css">
</head>
<body>
    <div class="login">
        <h1 class="text-center">Login</h1>
        <a href="home.php">Go back</a>
        <br><br>
        <?php
        if (isset($_SESSION['login'])) {
            echo $_SESSION['login'];
            unset($_SESSION['login']);
        }
        if (isset($_SESSION['no-login-message'])) {
            echo $_SESSION['no-login-message'];
            unset($_SESSION['no-login-message']);
        }
        ?>
        <br><br>
        <!-- Login form start here -->
        <form action="" method="POST" class="text-center"> <!-- Action changed to empty to post to the same page -->
            UserName: <br>
            <input type="text" name="full_name" placeholder="Enter Full Name" required><br><br>
            Password: <br>
            <input type="password" name="password" placeholder="Enter Password" required><br><br>
            <a href="signup.php">Create new account</a>
            <br><br>
            <input type="submit" name="submit" value="Login" class="btn-primary">
            <br><br>
        </form>
        <!-- Login form end here -->
        
    </div>
</body>
</html>

<?php
// Check whether the Submit button is clicked or not
if (isset($_POST['submit'])) {
    // Process for login
    // 1. Get the data from login form
    $full_name = $_POST['full_name']; // Use full_name for the field
    $password = md5($_POST['password']); // Hashing the password

    // 2. SQL to check whether the user with full_name and password exists or not
    $sql = "SELECT id, full_name FROM tbl_user WHERE full_name = ? AND password = ?"; // Fetch the user id as well

    // 3. Prepare the statement
    $stmt = mysqli_prepare($conn, $sql);
    if ($stmt === false) {
        die('MySQL prepare statement error: ' . mysqli_error($conn));
    }

    // 4. Bind parameters to the statement
    mysqli_stmt_bind_param($stmt, "ss", $full_name, $password);

    // 5. Execute the statement
    mysqli_stmt_execute($stmt);

    // 6. Get the result
    $res = mysqli_stmt_get_result($stmt);

    // 7. Count rows to check whether the user exists or not
    $count = mysqli_num_rows($res);

    if ($count == 1) {
        // User available and login successful
        $row = mysqli_fetch_assoc($res);
        $user_id = $row['id']; // Fetch the user id from the result

        // Create login session
        $_SESSION['login'] = "<div>Login successful.</div>";
        $_SESSION['user'] = $full_name; // Store full_name in session for further use
        $_SESSION['user_id'] = $user_id; // Store user_id in session

        // Redirect to home
        header('Location: index.php');
        exit();
    } else {
        // User not available
        $_SESSION['login'] = "<div>Username or password did not match.</div>";
        // Redirect to login page
        header('Location: ' . SITEURL . 'login.php');
        exit();
    }
}
?>
