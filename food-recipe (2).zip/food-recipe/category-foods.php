<?php include('partials-front/menu.php'); ?>

<?php
if (isset($_GET['category_id'])) {
    // Category ID is set
    $category_id = $_GET['category_id'];

    // Get the category title based on category ID
    $sql = "SELECT title FROM tbl_category WHERE id=$category_id";
    $res = mysqli_query($conn, $sql);

    // Get the value from the database
    $row = mysqli_fetch_assoc($res);

    // Get the title
    $category_title = $row['title'];
} else {
    // Category ID is not set, redirect to home page
    header('Location:' . SITEURL);
}
?>

<!-- fOOD sEARCH Section Starts Here -->
<section class="food-search text-center">
    <div class="container">
        <h2>Foods on <a href="#" class="text-white"><?php echo $category_title; ?></a></h2>
    </div>
</section>
<!-- fOOD sEARCH Section Ends Here -->

<!-- fOOD MEnu Section Starts Here -->
<section class="food-menu">
    <div class="container">
        <h2 class="text-center">Food Recipe</h2>

        <?php
        // Create SQL query to display food from the selected category
        $sql2 = "SELECT * FROM tbl_food WHERE category_id=$category_id AND active='Yes' LIMIT 10";
        $res2 = mysqli_query($conn, $sql2);
        $count2 = mysqli_num_rows($res2);

        if ($count2 > 0) {
            // Food available
            while ($row = mysqli_fetch_assoc($res2)) {
                // Get the values like title, price, description, and image_name
                $id = $row['id'];
                $title = $row['title'];
                $image_name = $row['image_name'];
                ?>
                <div class="food-menu-box">
                    <div class="food-menu-img">
                        <?php
                        if ($image_name == "") {
                            // Image not available
                            echo "<div style='color:red'>Image not available.</div>";
                        } else {
                            // Image available
                            ?>
                            <img src="<?php echo SITEURL; ?>images/food/<?php echo $image_name; ?>" alt="<?php echo $title; ?>" class="img-responsive img-curve">
                            <?php
                        }
                        ?>
                    </div>
                    <div class="food-menu-desc">
                        <h4><?php echo $title; ?></h4>
                        
                        <br>
                        <a href="<?php echo SITEURL;?>view.php?food_id=<?php echo $id; ?>" class="btn btn-primary" >view</a>
                    </div>
                </div>
                <?php
            }
        } else {
            // Food not available
            echo "<div style='color:red'>Food not added</div>";
        }
        ?>

        <div class="clearfix"></div>
    </div>

    
</section>
<!-- fOOD Menu Section Ends Here -->
