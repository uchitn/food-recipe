
    <?php 
        include('partials/menu.php');
        ?>

        <!--Main Section Stat-->
        <div class="main-content">
        <div class="wrapper">
        <h1>DASHBOARD</h1>
        <br><br>

        <?php
            if(isset($_SESSION['login']))
            {
                echo $_SESSION['login'];
                unset($_SESSION['login']);
            }
        ?>
      <br><br>
        <div class="col-4 text-center">
            <?php
            $sql = "SELECT * FROM tbl_category";

            $res = mysqli_query($conn, $sql);

            $count = mysqli_num_rows($res);
            ?>

            <h1><?php echo $count;?></h1>
            <br>
            Category
        </div>
        <div class="col-4 text-center ">
        <?php
            $sql = "SELECT * FROM tbl_food";

            $res = mysqli_query($conn, $sql);

            $count = mysqli_num_rows($res);
            ?>
            <h1><?php echo $count;?></h1>  
            <br>
            Foods
        </div>
        <div class="col-4 text-center">
        <?php
            $sql = "SELECT * FROM tbl_user";

            $res = mysqli_query($conn, $sql);

            $count = mysqli_num_rows($res);
            ?>

            <h1><?php echo $count;?></h1>
            <br>
            User
        </div>
        <div class="col-4 text-center">
        <?php
            $sql = "SELECT * FROM tbl_feedback";

            $res = mysqli_query($conn, $sql);

            $count = mysqli_num_rows($res);
            ?>

            <h1><?php echo $count;?></h1>
            <br>
            Feedback
        </div>
        <div class="clearfix"></div>
            </div>
        </div>
        <!--Main Section End-->

      
        