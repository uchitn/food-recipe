<?php include('partials/menu.php');?>

    <div class="main-content">
        <div class="wrapper">
            <h1>Add Category</h1>
            <br><br>
            <?php
            if(isset($_SESSION['add'])) {
                echo $_SESSION['add'];
                unset($_SESSION['add']);
            }

            if(isset($_SESSION['upload'])) {
                echo $_SESSION['upload'];
                unset($_SESSION['upload']);
            }
            ?>
            <br><br>
            
            <!-- add category form starts -->
             <form action="" method="POST" enctype="multipart/form-data">
                <table class="tbl-30">
                    <tr>
                        <td>Title:</td>
                        <td>
                            <input type="text" name="title" placeholder="Enter Category Title">
                        </td>
                    </tr>
                    
                    <tr>
                        <td colspan="2">
                            <input type="submit" name="submit" value="Add Category" class="btn-add">
                        </td>
                    </tr>
                </table>
             </form>    
            <!-- add category form end -->

            <?php
// Check whether the submit button is clicked or not 
if (isset($_POST['submit'])) {
    // Get the value from category form 
    $title = $_POST['title'];

    // Create SQL query to insert category into database
    $sql = "INSERT INTO tbl_sub_category SET
        title = '$title'";

    // Execute the query and save in database
    $res = mysqli_query($conn, $sql);

    // Check whether the query executed or not and data added or not
    if ($res == true) {
        // Query executed and category added 
        $_SESSION['add'] = "<div style='color:green'>Sub-Category Added Successfully.</div>";
        header('location:' . SITEURL . 'admin/manage-sub-category.php');
    } else {
        // Failed to add category
        $_SESSION['add'] = "<div style='color:red'>Failed To Add Sub-Category</div>";
        header('location:' . SITEURL . 'admin/add-sub-category.php');
    }
}
?>

        </div>
    </div>


            