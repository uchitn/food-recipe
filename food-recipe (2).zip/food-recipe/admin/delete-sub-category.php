<?php
include('../config/constants.php');

// Check if the 'id' is set in the URL or not
if(isset($_GET['id'])) {
    $id = $_GET['id'];

    // Delete data from database
    $sql = "DELETE FROM tbl_sub_category WHERE id=$id";

    // Execute the query
    $res = mysqli_query($conn, $sql);

    // Check whether the data is deleted from the database or not
    if ($res == true) {
        // Set the session message
        $_SESSION['delete'] = "<div style='color:green'>Category deleted successfully</div>";
        // Redirect to manage category page
        header('location:' . SITEURL . 'admin/manage-sub-category.php');
    } else {
        // Set the session message
        $_SESSION['delete'] = "<div style='color:red'>Failed to delete category</div>";
        // Redirect to manage category page
        header('location:' . SITEURL . 'admin/manage-sub-category.php');
    }
} else {
    // Redirect to manage category page if 'id' is not set
    header('location:' . SITEURL . 'admin/manage-sub-category.php');
}
?>
