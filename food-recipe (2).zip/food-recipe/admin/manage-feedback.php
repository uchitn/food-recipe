<?php 
// Include the menu if available
if (file_exists('partials/menu.php')) {
    include('partials/menu.php'); 
} else {
    echo "<div style='color:red;'>Menu file not found.</div>";
}
?>

<div class="main-content">
    <div class="wrapper">
        <h1>Manage Feedback</h1>
        <br><br>

        <?php
        // Database connection
        $conn = mysqli_connect('localhost', 'root', '', 'food-recipe') or die(mysqli_error());

        // Check if a delete request was made
        if (isset($_POST['delete'])) {
            $feedback_id = $_POST['feedback_id'];
            $delete_sql = "DELETE FROM tbl_feedback WHERE id=$feedback_id";
            $delete_res = mysqli_query($conn, $delete_sql);

            if ($delete_res) {
                echo "<div style='color:green;'>Feedback deleted successfully.</div>";
            } else {
                echo "<div style='color:red;'>Failed to delete feedback.</div>";
            }
        }

        // Query to get all feedback from the database
        $sql = "SELECT * FROM tbl_feedback";
        $res = mysqli_query($conn, $sql);

        if ($res == true) {
            $count = mysqli_num_rows($res);

            if ($count > 0) {
                // Display feedback in boxes
                while ($row = mysqli_fetch_assoc($res)) {
                    $id = $row['id'];
                    $name = $row['name'];
                    $email = $row['email'];
                    $rating = $row['rating'];
                    $comments = $row['comments'];
                    $action = isset($row['action']) ? $row['action'] : 'No action specified'; // Check if 'action' key exists

                    ?>
                    <div class="feedback-box">
                        <h3><?php echo htmlspecialchars($name); ?></h3>
                        <p><strong>Email:</strong> <?php echo htmlspecialchars($email); ?></p>
                        <p><strong>Rating:</strong> <?php echo htmlspecialchars($rating); ?></p>
                        <p><strong>Comments:</strong> <?php echo nl2br(htmlspecialchars($comments)); ?></p>
                        
                        
                        <!-- Delete button -->
                        <form method="POST" action="">
                            <input type="hidden" name="feedback_id" value="<?php echo $id; ?>">
                            <input type="submit" name="delete" value="Delete" style="background-color: red; color: white; padding: 5px 10px; border: none; cursor: pointer;">
                        </form>
                    </div>
                    <?php
                }
            } else {
                echo "<div style='color:red;'>No feedback found.</div>";
            }
        } else {
            echo "<div style='color:red;'>Failed to retrieve feedback data.</div>";
        }

        // Close the database connection
        mysqli_close($conn);
        ?>
    </div>
</div>
