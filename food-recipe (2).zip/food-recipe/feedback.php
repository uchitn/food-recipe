<?php 
include('partials-front/menu.php'); 
?>

<div class="main-content">
    <div class="wrapper">
        <h1>Submit Feedback</h1>
        <br><br>

        <?php
        if(isset($_POST['submit'])) {
            // Database connection
            $conn = mysqli_connect('localhost', 'root', '', 'food-recipe') or die(mysqli_error());

            // Get form data
            $name = $_POST['name'];
            $email = $_POST['email'];
            $rating = $_POST['rating'];
            $comments = $_POST['comments'];

            // Validate email
            if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                // Insert feedback into the database
                $sql = "INSERT INTO tbl_feedback (name, email, rating, comments) VALUES ('$name', '$email', '$rating', '$comments')";
                $res = mysqli_query($conn, $sql);

                if($res == true) {
                    echo "<div style='color:green;'>Feedback submitted successfully!</div>";
                } else {
                    echo "<div style='color:red;'>Failed to submit feedback. Please try again later.</div>";
                }
            } else {
                echo "<div style='color:red;'>Invalid email address. Please enter a valid email.</div>";
            }

            // Close the database connection
            mysqli_close($conn);
        }
        ?>

        <form action="" method="POST">
            <table class:Feedback>
                <tr>
                    <td>Name:</td>
                    <td>
                        <input type="text" name="name" required>
                    </td>
                </tr>
                <tr>
                    <td>Email:</td>
                    <td>
                        <input type="email" name="email" required>
                    </td>
                </tr>
                <tr>
                    <td>Rating:</td>
                    <td>
                        <select name="rating" required>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Comments:</td>
                    <td>
                        <textarea name="comments" cols="30" rows="5" required></textarea>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <input type="submit" name="submit" value="Submit Feedback" class="btn-add">
                    </td>
                </tr>
            </table>
        </form>
    </div>
</div>

