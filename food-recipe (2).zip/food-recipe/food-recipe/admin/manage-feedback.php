<?php include('partials/menu.php'); ?>
<div class="main-content">
<div class="wrapper">
    <h1>Manage Feedback</h1>
</div>
   
     

    <table class="tbl-full">
            <tr>
                <th>S.N</th>
                <th>Full Name</th>
                <th>Email</th>
                <th>Contact</th>
                <th>Action</th>
            </tr>
            <tr>
                <td>1.</td>
                <td>Uchit Shrestha</td>
                <td>Shresthauchit@gmail.com</td>
                <td>1234567890</td>
                <td>
                   <a href="#" class="btn-primary">Update User</a>
                    <a href="#" class="btn-danger" >Delete Admin</a>
                </td>
            </tr>
            <tr>
                <td>1.</td>
                <td>Uchit Shrestha</td>
                <td>Shresthauchit@gmail.com</td>
                <td>1234567890</td>
                <td>
                <a href="#" class="btn-primary">Update User</a>
                <a href="#" class="btn-danger" >Delete Admin</a>
                </td>
            </tr>
            <tr>
                <td>1.</td>
                <td>Uchit Shrestha</td>
                <td>Shresthauchit@gmail.com</td>
                <td>1234567890</td>
                <td>
                <a href="#" class="btn-primary">Update User</a>
                <a href="#" class="btn-danger" >Delete Admin</a>
                </td>
            </tr>
        </table>
</div>

