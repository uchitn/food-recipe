<?php
include('partials-front/menu.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Recipe Recommendation</title>
    <style>
        /* style.css */




form {
    background-color: #ffffff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    width: 100%;
    max-width: 400px;
    margin-top: 50px;
}

label {
    font-size: 16px;
    color: #333;
}

input[type="text"] {
    width: 100%;
    padding: 10px;
    margin-top: 8px;
    border: 1px solid #ced4da;
    border-radius: 4px;
    font-size: 16px;
}

button[type="submit"] {
    margin-top: 20px;
    padding: 10px;
    width: 100%;
    background-color: #007bff;
    color: #fff;
    font-size: 16px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

button[type="submit"]:hover {
    background-color: #0056b3;
}

    </style>
</head>
<body>
    <h1>Find Recipes Based on Your Ingredients</h1>
    <form action="recommendation.php" method="POST">
        <label for="ingredients">Enter Ingredients (comma-separated):</label><br>
        <input type="text" id="ingredients" name="ingredients" placeholder="e.g., tomato, onion, garlic" required>
        <br><br>
        <button type="submit">Find Recipes</button>
    </form>
</body>
</html>