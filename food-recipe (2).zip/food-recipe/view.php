<?php
include('partials-front/menu.php');

if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id']; // Safely access user_id
} else {
    // Handle the case where the user is not logged in
    echo "User is not logged in.";
    // Optionally redirect to login page
    header('Location: login.php');
    exit();
}

// Check whether food id is set or not
if(isset($_GET['food_id'])){
    $food_id = $_GET['food_id'];

    // Fetch food details
    $sql = "SELECT * FROM tbl_food WHERE id = '$food_id'";
    $res = mysqli_query($conn, $sql);

    $count = mysqli_num_rows($res);

    if($count == 1){
        $row = mysqli_fetch_assoc($res);
        $title = $row['title'];
        $ingredients = $row['ingredients'];
        $description = $row['description'];
        $image_name = $row['image_name'];
    }
    else{
        header('location:'.SITEURL.'home.php');
    }
}
    // Check if the user has already viewed this food
    
?>

<!-- fOOD sEARCH Section Starts Here -->
<section class="food-search">
    <div class="container">
        
        <h2 class="text-center text-white"><?php echo $title; ?></h2>

        <form action="#" class="order">
            <fieldset>
                <div>
                    <?php
                    if($image_name == ""){
                        echo "<div style='color:red'>Image not available.</div>";
                    }
                    else{
                        ?>
                        <img src="<?php echo SITEURL; ?>images/food/<?php echo $image_name; ?>" alt="Food Image">
                        <?php
                    }
                    ?>
                </div>
                <br><br><br>

                <div>
                    <h1>Ingredients:</h1>
                    <ul class="food-price">
                        <?php
                        $ingredients_list = explode(",", $ingredients);
                        foreach($ingredients_list as $ingredient){
                            echo "<li>" . trim($ingredient) . "</li>";
                        }
                        ?>
                    </ul>
                </div>

            </fieldset>
            
            <fieldset>
                <legend>Step for making recipe</legend>
                <h1>Procedure:</h1>
                <ol class="food-price">
                    <?php
                    $steps = explode("\n", $description);
                    foreach($steps as $step){
                        echo "<li>" . trim($step) . "</li>";
                    }
                    ?>
                </ol>
            </fieldset>

        </form>

    </div>
</section>
<!-- fOOD sEARCH Section Ends Here -->


