    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Recipe Recommendation</title>
        <style>
            /* Basic styles */
            body {
                font-family: Arial, sans-serif;
                background-color: #f8f8f8;
                color: #333;
                margin: 0;
                padding: 0;
            }

            /* Container for the recommended recipes */
            .recipe-container {
                max-width: 800px;
                margin: 30px auto;
                padding: 20px;
                background-color: #fff;
                border-radius: 10px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            }

            /* Heading for the recommended recipes section */
            h1, h2 {
                text-align: center;
                color: #ff6f61;
            }

            /* Style for each recipe */
            .recipe {
                background-color: #f9f9f9;
                padding: 15px;
                border-radius: 8px;
                margin-bottom: 20px;
                border: 1px solid #ddd;
            }

            .recipe strong {
                font-weight: bold;
            }

            /* Recipe image */
            .recipe img {
                max-width: 100%;
                height: auto;
                border-radius: 8px;
                margin-bottom: 10px;
                display: block;
            }

            /* Match percentage styling */
            .match-percentage {
                color: #28a745;
                font-weight: bold;
            }

            /* No recipes found message */
            p {
                color: #ff6347;
                font-weight: bold;
                text-align: center;
            }

            /* Responsive layout for smaller screens */
            @media (max-width: 600px) {
                .recipe-container {
                    padding: 10px;
                    margin: 20px;
                }

                .recipe {
                    padding: 10px;
                }
            }
        </style>
    </head>
    <body>

    

        <?php
        include('partials-front/menu.php'); // Make sure this file establishes a $conn connection to the database

        // Check if form is submitted
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Get and sanitize user input
            $ingredients_input = filter_input(INPUT_POST, 'ingredients', FILTER_SANITIZE_STRING);
            $user_ingredients = array_map('trim', explode(',', $ingredients_input)); // User ingredients

            // Convert user ingredients to lowercase
            $user_ingredients = array_map('strtolower', $user_ingredients);

            // Function to calculate Jaccard similarity
            function jaccardSimilarity($user_ingredients, $recipe_ingredients) {
                $user_ingredients = array_unique($user_ingredients);
                $recipe_ingredients = array_unique($recipe_ingredients);
                $intersection = array_intersect($user_ingredients, $recipe_ingredients);
                $union = array_unique(array_merge($user_ingredients, $recipe_ingredients));
                return count($intersection) / count($union);
            }

            // Function to recommend recipes
            function recommendRecipes($user_ingredients, $conn) {
                $recommendations = [];
                $stmt = $conn->query("SELECT id, title, ingredients, image_name FROM tbl_food");
                $recipes = [];
                while ($row = $stmt->fetch_assoc()) {
                    $recipes[] = $row;
                }

                foreach ($recipes as $recipe) {
                    $recipe_ingredients = array_map('strtolower', array_map('trim', explode(',', $recipe['ingredients'])));
                    $similarity = jaccardSimilarity($user_ingredients, $recipe_ingredients);
                    if ($similarity > 0) {
                        $recommendations[] = [
                            'id' => $recipe['id'],
                            'name' => $recipe['title'],
                            'similarity' => $similarity,
                            'ingredients' => $recipe['ingredients'],
                            'image_name' => $recipe['image_name'] // Add the image name
                        ];
                    }
                }

                usort($recommendations, function($a, $b) {
                    return $b['similarity'] <=> $a['similarity'];
                });

                return $recommendations;
            }

            // Get recommendations
            $recommendations = recommendRecipes($user_ingredients, $conn);

            // Display the user's searched ingredients
            echo "<div class='recipe-container'>";
            echo "<h2>Your Searched Ingredients</h2>";
            echo "<p><strong>Ingredients:</strong> " . htmlspecialchars(implode(', ', $user_ingredients)) . "</p>";

            // Display recommendations
            echo "<h2>Recommended Recipes</h2>";
            if (count($recommendations) > 0) {
                foreach ($recommendations as $recommendation) {
                    echo "<div class='recipe'>";
                    echo "<strong>Recipe: </strong>" . htmlspecialchars($recommendation['name']) . "<br>";
                    echo "<strong>Match Percentage: </strong><span class='match-percentage'>" . round($recommendation['similarity'] * 100, 2) . "%</span><br>";
                    echo "<strong>Ingredients: </strong>" . htmlspecialchars($recommendation['ingredients']) . "<br>";

                    // Display the recipe image
                    if (!empty($recommendation['image_name'])) {
                        echo "<img src='images/food/" . htmlspecialchars($recommendation['image_name']) . "' alt='" . htmlspecialchars($recommendation['name']) . "'><br>";
                    } else {
                        echo "<p>No image available.</p>";
                    }

                    echo "<a href='view.php?food_id=" . $recommendation['id'] . "'>View Recipe</a>";
                    echo "</div><br><br>";
                }
            } else {
                echo "<p>No recipes found matching your ingredients. Please try different ingredients.</p>";
            }
            echo "</div>";
        }
        ?>

    </body>
    </html>
